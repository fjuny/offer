INSERT INTO offer(id, des, type, pts, rebate, start, endd) VALUES(001, 'A101', 'Points', 20, 5, '01/20/2021','01/22/2021');

COMMIT;